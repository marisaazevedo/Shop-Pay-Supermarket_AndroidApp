package org.feup.apm.nfcreader

import android.graphics.Color
import android.nfc.NfcAdapter
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.activity.SystemBarStyle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar

const val READER_FLAGS = NfcAdapter.FLAG_READER_NFC_A or NfcAdapter.FLAG_READER_SKIP_NDEF_CHECK

class MainActivity : AppCompatActivity() {
  private val nfc by lazy { NfcAdapter.getDefaultAdapter(this) }
  private val cardReader by lazy { CardReader(::onCardNrReceived, ::onTagTechsReceived) }

  private val toolbar by lazy { findViewById<Toolbar>(R.id.toolbar) }
  private val tvAccNr by lazy { findViewById<TextView>(R.id.card_account_field) }
  private val tvTrSize by lazy { findViewById<TextView>(R.id.tv_tsize) }
  private val btClear by lazy { findViewById<Button>(R.id.bt_clear) }

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge(navigationBarStyle = SystemBarStyle.light(Color.TRANSPARENT, Color.TRANSPARENT))
    setContentView(R.layout.activity_main)
    setStatusBarIconColor(window, Lightness.LIGHT)
    setSupportActionBar(toolbar)
    setInsetsPadding(toolbar, top=dpToPx(-8f))
    if (nfc == null) {
      Toast.makeText(this, "NFC adapter not present!", Toast.LENGTH_LONG).show()
      finish()
    }
    btClear.setOnClickListener { tvAccNr.setText(R.string.tv_accnr)
                                 tvTrSize.text = "" }
  }

  override fun onPause() {
    super.onPause()
    nfc.disableReaderMode(this)
  }

  override fun onResume() {
    super.onResume()
    nfc.enableReaderMode(this, cardReader, READER_FLAGS, null)
  }

  private fun onTagTechsReceived(tagTechs: String) {
    runOnUiThread { tvTrSize.text = tagTechs }
  }

  private fun onCardNrReceived(accountNr: String) {
    runOnUiThread { tvAccNr.text = accountNr }
  }
}