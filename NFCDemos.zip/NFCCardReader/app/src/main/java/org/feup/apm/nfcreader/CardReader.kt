package org.feup.apm.nfcreader

import android.nfc.NfcAdapter.ReaderCallback
import android.nfc.Tag
import android.nfc.tech.IsoDep
import android.util.Log
import java.io.IOException
import java.util.*

private const val LOYALTY_CARD_AID = "F222222222"
private const val SELECT_APDU_HEADER = "00A40400"
private val SELECT_OK_SW = hexStringToByteArray("9000")

/* Top-level utility functions */
fun hexStringToByteArray(s: String): ByteArray {
  val data = ByteArray(s.length/2)
  for (k in 0 until s.length/2)
    data[k] = ((Character.digit(s[2*k], 16) shl 4) + Character.digit(s[2*k+1], 16)).toByte()
  return data
}

class CardReader(private val accNrListener: (String)->Unit, private val tagTechsListener: (String)->Unit) : ReaderCallback {
  override fun onTagDiscovered(tag: Tag) {
    tagTechsListener(tag.toString().replace("android.nfc.tech.", ""))                 // transmit the reported tag
    val isoDep = IsoDep.get(tag)                    // Android smart card reader emulator
    if (isoDep != null) {
      try {
        isoDep.connect()                            // establish a connection with the card and send 'select aid' command
        val result = isoDep.transceive(hexStringToByteArray(SELECT_APDU_HEADER + String.format("%02X", LOYALTY_CARD_AID.length/2) + LOYALTY_CARD_AID))
        val rLen = result.size
        val status = byteArrayOf(result[rLen-2], result[rLen-1])
        val payload = Arrays.copyOf(result, rLen-2)
        if (SELECT_OK_SW.contentEquals(status))
          accNrListener(String(payload, Charsets.UTF_8))      // pass the read account number
      }
      catch (e: IOException) {
        Log.e("CardReader", "Error communicating with card: $e")
      }
    }
  }
}
