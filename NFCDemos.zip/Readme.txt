This pair of apps demonstrate the ability of Android to simulate Wireless SmartCards
in software (using the Card Emulation mode of NFC).
SmartCards contain applets that can accept commands (inputs in byte APDU format) generating
replies if recognized in the applet software. These commands and results are transmitted
in a serial line (in the standard smartcard connector) or using a NFC channel.
Each applet has an associated AID (a 5 to 13 byte number) and the first operation
for using it must be a "select AID" command sent to the smartcard.
A smartcard can have several applets installed with different AIDs.

NFC Reader
==========

Implements a reader of NFC Smartcards using the IsoDep protocol and a smartcard (as the one emulated
in the next app). After detecting the presence of the card (NFC channel established)
it emits the "select AID" command (using the same AID as the one associated with the applet
emulated in the next app), and reads the reply. If the reply is valid, it shows the
payload, that, in this case, contains only a number (the card number that the user has defined for his card).

NFC Card Emulator
===============

Android allows the simulation of a smartcard applet in a special service that will work
with the NFC controller. That service should derive from the HostApduService class in the Android library.
The associated AID is defined in a XML resource of the app (in the res/xml directory).
In this simple example, the applet, when selected, returns imediatelly a number (representing the card
number, that can be changed and persisted (in an Android Preference) in the Android application Activity).
The simple installation of the application (with the device NFC enabled), makes the device respond
to NFC readers that select the emulated applet, as if it was a physical SmartCard.


The two previous apps should be installed in different devices and require API 19 (Android 4.4 KitKat)
or later and support from the NFC hardware (not all devices with NFC and API 19 are capable of working in
Card Emulation mode).
