package org.feup.apm.nfccard

import android.nfc.cardemulation.HostApduService
import android.os.Bundle

private const val LOYALTY_CARD_AID = "F222222222" // AID for this applet service.
private const val SELECT_AID_HEADER = "00A40400" // SmartCard 'select AID' command

/* Top-level utility functions */
fun hexStringToByteArray(s: String): ByteArray {
  val data = ByteArray(s.length/2)
  for (k in 0 until s.length/2)
    data[k] = ((Character.digit(s[2*k], 16) shl 4) + Character.digit(s[2*k+1], 16)).toByte()
  return data
}

class CardService : HostApduService() {
  private val OK_SW = hexStringToByteArray("9000")             // "OK" status word (0x9000)
  private val UNKNOWN_CMD_SW = hexStringToByteArray("0000")    // "UNKNOWN" status word (0X0000)
  private val SELECT_AID_APDU = hexStringToByteArray(SELECT_AID_HEADER + String.format("%02X", LOYALTY_CARD_AID.length/2) + LOYALTY_CARD_AID)

  // return card account on Select command (with correct AID)
  override fun processCommandApdu(command: ByteArray, bundle: Bundle?): ByteArray {
    return if (SELECT_AID_APDU.contentEquals(command))
      AccountNrStore.getAccount(this).toByteArray() + OK_SW
    else
      UNKNOWN_CMD_SW
  }

  override fun onDeactivated(i: Int) {}
}
