package org.feup.apm.nfccard

import android.content.Context
import androidx.preference.PreferenceManager
import android.widget.TextView

// Card number backed by a persisted preference in Android
object AccountNrStore {
  private const val PREF_ACCOUNT_NUMBER = "account_number"
  private const val DEFAULT_ACCOUNT_NUMBER = "00000000"
  private val accountLock = Any()
  private var account = ""                   // global state of the app

  fun getAccount(c: Context): String {
    synchronized(accountLock) {
      if (account.isEmpty())
        account = PreferenceManager.getDefaultSharedPreferences(c).getString(PREF_ACCOUNT_NUMBER, DEFAULT_ACCOUNT_NUMBER)!!
      return account
    }
  }

  fun setAccount(c: Context, tv: TextView, value: String) {
    synchronized(accountLock) {
      tv.text = String.format(c.getString(R.string.tv_state_template), tv.text, value)
      PreferenceManager.getDefaultSharedPreferences(c).edit().putString(PREF_ACCOUNT_NUMBER, value).apply()
      account = value
    }
  }
}