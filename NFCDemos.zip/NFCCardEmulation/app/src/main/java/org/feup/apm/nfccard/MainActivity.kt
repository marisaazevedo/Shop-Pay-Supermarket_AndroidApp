package org.feup.apm.nfccard

import android.graphics.Color
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.TextView
import androidx.activity.SystemBarStyle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar

class MainActivity : AppCompatActivity() {
  private val toolbar by lazy { findViewById<Toolbar>(R.id.toolbar) }
  private val flCard by lazy { findViewById<FrameLayout>(R.id.fl_card) }
  private val tvOutput by lazy { findViewById<TextView>(R.id.tv_output) }
  private val edtAccount by lazy { findViewById<EditText>(R.id.card_account_field) }
  private val btSave by lazy { findViewById<Button>(R.id.button_save) }

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge(navigationBarStyle = SystemBarStyle.light(Color.TRANSPARENT, Color.TRANSPARENT))
    setContentView(R.layout.activity_main)
    setStatusBarIconColor(window, Lightness.LIGHT)
    setSupportActionBar(toolbar)
    setInsetsPadding(toolbar, top=dpToPx(-8f))
    setInsetsPadding(flCard, left=dpToPx(10f), right=dpToPx(10f))
    setInsetsPadding(tvOutput, left=dpToPx(10f), right=dpToPx(10f), bottom=0)
    btSave.setOnClickListener { onBtSaveClick() }
    edtAccount.setText(AccountNrStore.getAccount(this))
    tvOutput.setText(R.string.tv_state_ready)
  }

  private fun onBtSaveClick() {
    var accNr = edtAccount.text.toString()
    accNr = if (accNr.length < 8)
      accNr.padStart(8, '0')
    else
      accNr.substring(0, 8)
    AccountNrStore.setAccount(this, tvOutput, accNr)
    edtAccount.setText(AccountNrStore.getAccount(this))
  }
}
