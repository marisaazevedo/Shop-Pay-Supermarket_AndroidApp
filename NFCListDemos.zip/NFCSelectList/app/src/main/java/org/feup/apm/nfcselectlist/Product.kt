package org.feup.apm.nfcselectlist

import android.app.Activity
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.CheckBox
import android.widget.TextView

val productNames = arrayOf(
  "Oranges",
  "Mandarins",
  "Peaches",
  "Pears",
  "Apples",
  "Pineapples",
  "Plums",
  "Grapes"
)
var listProducts = ArrayList<Product>()

data class Product(val name: String, val type: Byte) {
  var selected = false
}

class ModelAdapter(private val ctx: Activity, private val list: ArrayList<Product>) : ArrayAdapter<Product>(ctx, R.layout.adapter_product_item, list) {
  override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
    val itemView = convertView ?: ctx.layoutInflater.inflate(R.layout.adapter_product_item, parent, false)
    with(list[position]) {
      itemView.findViewById<TextView>(R.id.item_name).text = name
      with(itemView.findViewById<CheckBox>(R.id.item_check)) {
        isChecked = selected
        setOnClickListener {
          selected = isChecked
        }
      }
    }
    return itemView
  }
}
