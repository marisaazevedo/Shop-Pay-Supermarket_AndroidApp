package org.feup.apm.nfcselectlist

import android.graphics.Color
import android.os.Bundle
import android.widget.TextView
import androidx.activity.SystemBarStyle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar

class ShowKeysActivity : AppCompatActivity() {
  private val toolbar by lazy { findViewById<Toolbar>(R.id.toolbar) }
  private val tv by lazy { findViewById<TextView>(R.id.tv_keys) }

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge(navigationBarStyle = SystemBarStyle.light(Color.TRANSPARENT, Color.TRANSPARENT))
    setContentView(R.layout.activity_showkeys)
    setSupportActionBar(toolbar)
    setInsetsPadding(toolbar, top=dpToPx(-8f))
    setStatusBarIconColor(window, Lightness.LIGHT)
    val modulus = intent.getByteArrayExtra("modulus")!!
    val exponent = intent.getByteArrayExtra("exponent")!!
    val privExp = intent.getByteArrayExtra("priv")!!
    val text =
      """
        Modulus(${modulus.size}):
        ${byteArrayToHex(modulus)}
        
        Exponent: ${byteArrayToHex(exponent)}
        
        Priv Exp(${privExp.size}):
        ${byteArrayToHex(privExp)}
      """.trimIndent()
    tv.text = text
  }
}
