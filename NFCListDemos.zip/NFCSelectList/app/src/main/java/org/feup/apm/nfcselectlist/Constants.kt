package org.feup.apm.nfcselectlist

/* Utility top-level function */
fun byteArrayToHex(ba: ByteArray): String {
  val sb = StringBuilder(ba.size * 2)
  for (b in ba) sb.append(String.format("%02x", b))
  return sb.toString()
}

fun hexStringToByteArray(s: String): ByteArray {
  val data = ByteArray(s.length/2)
  for (k in 0 until s.length/2)
    data[k] = ((Character.digit(s[2*k], 16) shl 4) + Character.digit(s[2*k+1], 16)).toByte()
  return data
}

object Constants {
  const val KEY_SIZE = 512
  const val ANDROID_KEYSTORE = "AndroidKeyStore"
  const val KEY_ALGO = "RSA"
  const val SIGN_ALGO = "SHA256WithRSA"
  const val KeyName = "IdListSignKey"
  const val ACTION_CARD_DONE = "CMD_PROCESSING_DONE"
}