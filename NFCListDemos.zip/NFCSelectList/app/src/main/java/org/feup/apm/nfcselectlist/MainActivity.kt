package org.feup.apm.nfcselectlist

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ListView
import androidx.activity.SystemBarStyle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import java.math.BigInteger
import java.nio.ByteBuffer
import java.security.KeyPairGenerator
import java.security.KeyStore
import java.security.Signature
import java.security.interfaces.RSAPrivateKey
import java.security.interfaces.RSAPublicKey
import java.util.*
import javax.security.auth.x500.X500Principal
import kotlin.collections.ArrayList

const val logTag = "NFCSelectList"

class MainActivity : AppCompatActivity() {
  inner class PubKey {
    var modulus = ByteArray(0)
    var exponent = ByteArray(0)
  }

  private val toolbar by lazy { findViewById<Toolbar>(R.id.toolbar) }
  private val screen by lazy { findViewById<LinearLayout>(R.id.ll_screen) }
  private val list by lazy { findViewById<ListView>(R.id.lv_items) }
  private val btSend by lazy { findViewById<Button>(R.id.bt_send) }
  private val btQR by lazy { findViewById<Button>(R.id.bt_qr) }

  private val pubKey: PubKey    // class property representing the RSA public key within the Android Key store
    get() {                     // when read it returns the public key as modulus + exponent in a PubKey object
      val pKey = PubKey()
      try {
        val entry = KeyStore.getInstance(Constants.ANDROID_KEYSTORE).run {
          load(null)
          getEntry(Constants.KeyName, null)
        }
        val pub = (entry as KeyStore.PrivateKeyEntry).certificate.publicKey
        pKey.modulus = (pub as RSAPublicKey).modulus.toByteArray()
        pKey.exponent = pub.publicExponent.toByteArray()
      }
      catch (ex: Exception) {
        Log.d(logTag, ex.toString())
      }
      return pKey
    }
  private val privExp: ByteArray            // the same for the private exponent
    get() {                                 // as the private key is inside the Android Key store, it should not be readable (resul is empty ByteArray)
      var exp = ByteArray(0)
      try {
        val entry = KeyStore.getInstance(Constants.ANDROID_KEYSTORE).run {
          load(null)
          getEntry(Constants.KeyName, null)
        }
        exp = ((entry as KeyStore.PrivateKeyEntry).privateKey as RSAPrivateKey).privateExponent.toByteArray()
      }
      catch (ex: Exception) {
        Log.d(logTag, ex.toString())
      }
      return exp
    }
  private val items: ArrayList<Product>
    get() {
      if (listProducts.isEmpty())
        listProducts = ArrayList(productNames.map{ Product(it, (productNames.indexOf(it)+1).toByte()) })
      return listProducts
    }

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge(navigationBarStyle = SystemBarStyle.light(Color.TRANSPARENT, Color.TRANSPARENT))
    setContentView(R.layout.activity_main)
    setSupportActionBar(toolbar)
    setStatusBarIconColor(window, Lightness.LIGHT)
    setInsetsPadding(toolbar, top=dpToPx(-8f), left=0, right=0)
    setInsetsPadding(screen, bottom=0)
    list.adapter = ModelAdapter(this, items)
    btSend.setOnClickListener {
      val message = buildMessage(items)
      val intent = Intent(this, NFCSendActivity::class.java)
        .putExtra("message", message)
        .putExtra("valueType", 2)
      startActivity(intent)
    }
    btQR.setOnClickListener {
      val message = buildMessage(items)
      val intent = Intent(this, QRActivity::class.java).putExtra("data", message)
      startActivity(intent)
    }
    generateAndStoreKeys()
  }

  override fun onCreateOptionsMenu(menu: Menu): Boolean {
    menuInflater.inflate(R.menu.activity_main, menu)
    return true
  }

  override fun onOptionsItemSelected(item: MenuItem): Boolean {
    val pkey = pubKey
    val privExp = privExp
    when (item.itemId) {
      R.id.mn_nfcsend -> {
        val intent = Intent(this, NFCSendActivity::class.java)
          .putExtra("message", pkey.modulus)
          .putExtra("valueType", 1)
        startActivity(intent)
      }
      R.id.mn_showkeys -> {
        val showIntent = Intent(this, ShowKeysActivity::class.java)
          .putExtra("modulus", pkey.modulus)
          .putExtra("exponent", pkey.exponent)
          .putExtra("priv", privExp)
        startActivity(showIntent)
      }
      else -> return super.onOptionsItemSelected(item)
    }
    return true
  }

  private fun buildMessage(list: ArrayList<Product>): ByteArray {
    val sels = list.filter{ it.selected }.map{ it.type }                  // create a List of selected Product types   (List<Byte>)
    val message = ByteBuffer.allocate(sels.size+1 + Constants.KEY_SIZE/8).run {
      put(sels.size.toByte())
      put(sels.toByteArray())
      array()
    }
    try {
      val entry = KeyStore.getInstance(Constants.ANDROID_KEYSTORE).run {
        load(null)
        getEntry(Constants.KeyName, null)
      }
      val pri = (entry as KeyStore.PrivateKeyEntry).privateKey
      val sz = Signature.getInstance(Constants.SIGN_ALGO).run {
        initSign(pri)
        update(message, 0, sels.size+1)
        sign(message, sels.size+1, Constants.KEY_SIZE/8)
      }
      Log.d(logTag, "Sign size = $sz bytes.")
    }
    catch (ex: Exception) {
      Log.d(logTag, ex.toString())
    }
    return message
  }

  private fun generateAndStoreKeys() {
    try {
      val entry = KeyStore.getInstance(Constants.ANDROID_KEYSTORE).run {
        load(null)
        getEntry(Constants.KeyName, null)
      }
      if (entry == null) {
        val spec = KeyGenParameterSpec.Builder(Constants.KeyName, KeyProperties.PURPOSE_SIGN)
          .setKeySize(Constants.KEY_SIZE)                                          // key size
          .setDigests(KeyProperties.DIGEST_SHA256)                                 // digest algorithm for signatures
          .setSignaturePaddings(KeyProperties.SIGNATURE_PADDING_RSA_PKCS1)         // signature padding method
          .setCertificateSubject(X500Principal("CN=" + Constants.KeyName))   // certifate holding the public key properties ...
          .setCertificateSerialNumber(BigInteger.valueOf(12131415L))           // an arbitrary certificate Serial Number
          .setCertificateNotBefore(GregorianCalendar().time)
          .setCertificateNotAfter(GregorianCalendar().apply { add(Calendar.YEAR, 10) }.time)
          .build()
        KeyPairGenerator.getInstance(Constants.KEY_ALGO, Constants.ANDROID_KEYSTORE).run {    // algorithm: RSA
          initialize(spec)
          generateKeyPair()
        }
      }
    }
    catch (ex: Exception) {
      Log.d(logTag, ex.toString())
    }
  }
}