package org.feup.apm.nfcselectlist

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.activity.SystemBarStyle
import androidx.activity.enableEdgeToEdge
import androidx.localbroadcastmanager.content.LocalBroadcastManager

class NFCSendActivity : AppCompatActivity() {
  private val broadcastReceiver = object: BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
      Toast.makeText(this@NFCSendActivity, "NFC link lost", Toast.LENGTH_LONG).show()
      finish()
    }
  }

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge(navigationBarStyle = SystemBarStyle.light(Color.TRANSPARENT, Color.TRANSPARENT))
    setContentView(R.layout.activity_nfcsend)
  }

  override fun onResume() {
    super.onResume()
    Card.contentMessage = intent.getByteArrayExtra("message") ?: ByteArray(0)       // message to send via card emulation
    Card.type = intent.getIntExtra("valueType", 0)                            // type of message (1: list, 2: key)
    val intentFilter = IntentFilter(Constants.ACTION_CARD_DONE)
    LocalBroadcastManager.getInstance(applicationContext).registerReceiver(broadcastReceiver, intentFilter)  // to receive 'link loss'
  }

  override fun onPause() {
    super.onPause()
    Card.type = 0  // allow sending only when this Activity is running
    LocalBroadcastManager.getInstance(applicationContext).unregisterReceiver(broadcastReceiver)
  }
}