This demo contains two apps, allowing the user to select items on a ListView, and transmitting the selected
on a message, cryptographically signed, to a second application.
The transmission can be done with QR codes, or using NFC, where the transmitter emulates a smart card, and the
receiver a card reader.

NFC Select List
===============
This app shows a list with their items selectable. It also can generate in the Android Key Store a pair of
RSA keys (public and private). It can transmit using NFC the public key, and also show its parameters.
He builds a message containing the list of the selected items, and signs it with the private key.
This message is put inside a smartcard emulator and made available to NFC readers.
It can also be used to generate a QR code, shown on the screen.

NFC Select Terminal
===================
This app is capable of read the messages made available by a smartcard, using a card reader, through NFC.
It can read and store (in memory) a public key. And also it can read a message containing a list of items
that were selected by the user of the other app. The message comes signed, and the signature is verified
with the stored public key. Both the items and the result of signature verification are displayed.
It can also scan a QR code containing the same message, and do the same thing with it.