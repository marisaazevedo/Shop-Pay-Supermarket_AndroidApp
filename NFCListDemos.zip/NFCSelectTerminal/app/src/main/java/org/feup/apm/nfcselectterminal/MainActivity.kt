package org.feup.apm.nfcselectterminal

import android.graphics.Color
import android.nfc.NfcAdapter
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.Button
import android.widget.TextView
import androidx.activity.SystemBarStyle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import com.journeyapps.barcodescanner.ScanContract
import com.journeyapps.barcodescanner.ScanOptions
import java.math.BigInteger
import java.nio.ByteBuffer
import java.security.KeyFactory
import java.security.PublicKey
import java.security.Signature
import java.security.spec.RSAPublicKeySpec

private var pubKey: PublicKey? = null         // will hold the public key (as long as the app is in memory)
private const val keysize = 512               // the public key will come with 512 bits
const val READER_FLAGS = NfcAdapter.FLAG_READER_NFC_A or NfcAdapter.FLAG_READER_SKIP_NDEF_CHECK
private val products = arrayOf(                       // the types of products (the first is type 1)
  "Oranges",
  "Mandarins",
  "Peaches",
  "Pears",
  "Apples",
  "Pineapples",
  "Plums",
  "Grapes"
)

/* Utility top-level function */
fun byteArrayToHex(ba: ByteArray): String {
  val sb = StringBuilder(ba.size * 2)
  for (b in ba) sb.append(String.format("%02x", b))
  return sb.toString()
}

fun hexStringToByteArray(s: String): ByteArray {
  val data = ByteArray(s.length/2)
  for (k in 0 until s.length/2)
    data[k] = ((Character.digit(s[2*k], 16) shl 4) + Character.digit(s[2*k+1], 16)).toByte()
  return data
}

class MainActivity : AppCompatActivity() {
  private val toolbar by lazy { findViewById<Toolbar>(R.id.toolbar) }
  private val tvContent by lazy { findViewById<TextView>(R.id.tv_content) }
  private val btClear by lazy { findViewById<Button>(R.id.bt_clear) }

  private val nfc by lazy { NfcAdapter.getDefaultAdapter(applicationContext) }
  private val nfcReader by lazy { NFCReader(::nfcReceived) }
  private val scanCodeLauncher = registerForActivityResult(ScanContract()) {
    if (it != null && it.contents != null) {
      showOrder(it.contents.toByteArray(Charsets.ISO_8859_1))
    }
  }

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge(navigationBarStyle = SystemBarStyle.light(Color.TRANSPARENT, Color.TRANSPARENT))
    setContentView(R.layout.activity_main)
    setSupportActionBar(toolbar)
    setInsetsPadding(toolbar, top=dpToPx(-8f))
    setStatusBarIconColor(window, Lightness.LIGHT)
    tvContent.setText(R.string.tv_waiting)
    btClear.setOnClickListener { tvContent.setText(R.string.tv_waiting) }
  }

  override fun onResume() {
    super.onResume()
    nfc.enableReaderMode(this, nfcReader, READER_FLAGS, null)
  }

  override fun onPause() {
    super.onPause()
    nfc.disableReaderMode(this)
  }

  override fun onCreateOptionsMenu(menu: Menu): Boolean {
    menuInflater.inflate(R.menu.activity_main, menu)
    return true
  }

  override fun onOptionsItemSelected(item: MenuItem): Boolean {
     return when (item.itemId) {
       R.id.mn_qr -> {
         scanOrderQR()
         true
       }
       else -> super.onOptionsItemSelected(item)
     }
  }

  // callback to receive a key or product list from the NFC reader
  private fun nfcReceived(type: Int, content: ByteArray) {
    runOnUiThread {
      when (type) {
        1 -> showAndStoreKey(content)
        2 -> showOrder(content)
      }
    }
  }

  // reading with a QR code (menu option)
  private fun scanOrderQR() {
    val options = ScanOptions().apply {
      setDesiredBarcodeFormats(ScanOptions.QR_CODE)
      setBeepEnabled(false)
      setOrientationLocked(true)
    }
    scanCodeLauncher.launch(options)
  }

  // when receiving a public key
  private fun showAndStoreKey(modulus: ByteArray) {
    var error = ""
    try {
      val keyRSAPub = RSAPublicKeySpec(BigInteger(modulus), BigInteger("65537"))   // the key raw values (as BigIntegers) are used to build an appropriate KeySpec
      pubKey = KeyFactory.getInstance("RSA").generatePublic(keyRSAPub)         // to build a key object we need a KeyFactory object
    }
    catch (ex: Exception) {
      error = ex.toString()
    }
    val sb = StringBuilder("Public Key:\nModulus (")
      .append(modulus.size)
      .append("):\n")
      .append(byteArrayToHex(modulus))
      .append("\nExponent: 010001\n\n")
      .append(error)
    tvContent.text = sb.toString()               // show the raw values of the key components (in hex)
  }

  // when receiving a list (comes with a signature)
  private fun showOrder(order: ByteArray) {
    var error = ""
    var validated = false
    val sb = StringBuilder()
    val nr = order[0].toInt()                           // get the nr of different products (first position)
    for (b in order.slice(1..nr)) {
      sb.append(" - ")
      sb.append(products[b-1])                         // get the name of each product from the type
      sb.append("\n")
    }
    if (pubKey == null)
      sb.append("\nMissing pub key.")
    else {
      val mess = ByteArray(nr+1)                   // extract the order and the signature from the all message
      val sign = ByteArray(keysize/8)
      val bb: ByteBuffer = ByteBuffer.wrap(order)
      bb.get(mess, 0, nr+1)
      bb.get(sign, 0, keysize/8)
      try {
        validated = Signature.getInstance("SHA256WithRSA").run {         // verify the signature with the public key
          initVerify(pubKey)
          update(mess)
          verify(sign)
        }
      }
      catch (ex: Exception) {
        error =
          """
                
            ${ex.message}
          """.trimIndent()
      }
    }
    sb.append("\nValidated = ")
    sb.append(validated)
    sb.append(error)
    tvContent.text = sb.toString()   // show list and validation
  }
}
