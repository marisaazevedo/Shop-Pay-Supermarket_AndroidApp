package org.feup.apm.eccrypto

// Cryptographic constants for this app

object Crypto {
  const val ANDROID_KEYSTORE = "AndroidKeyStore"
  const val KEY_ALGO = "EC"
  const val EC_CURVE = "secp256r1"
  const val SIGN_ALGO = "SHA256withECDSA"
  const val KeyName = "myECDemoKey"
  const val SerialNr = 1234567890L
}

// Constant strings for this app

object AppStrings {
  const val haveKeys = "generated"
  const val notHaveKeys = "not generated"
  const val beginCert = "-----BEGIN CERTIFICATE-----\n"
  const val endCert = "-----END CERTIFICATE-----\n"
  const val showKeysFormat = "Public X(%d):\n%s\nPublic Y(%d):\n%s\nPrivate S(%d):\n%s"
  const val contentFormat = "Content(%d):\n%s"
  const val signatureFormat = "Signature(%s):\n%s"
  const val certificateFormat = "DER(%d):\n%s\n\nPEM(b64:%d):\n%s\n%s"
}