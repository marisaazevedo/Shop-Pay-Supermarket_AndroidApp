package org.feup.apm.rsacrypto

// Cryptographic constants for this app

object Crypto {
  const val KEY_SIZE = 512
  const val ANDROID_KEYSTORE = "AndroidKeyStore"
  const val KEY_ALGO = "RSA"
  const val SIGN_ALGO = "SHA256WithRSA"
  const val ENC_ALGO = "RSA/NONE/PKCS1Padding"
  const val KeyName = "myDemoKey"
  const val SerialNr = 1234567890L
}

// Constant strings for this app

object AppStrings {
  const val haveKeys = "generated"
  const val notHaveKeys = "not generated"
  const val beginCert = "-----BEGIN CERTIFICATE-----\n"
  const val endCert = "-----END CERTIFICATE-----\n"
  const val showKeysFormat = "Modulus(%d):\n%s\nExponent: %s\nPrivate Exponent(%d):\n%s"
  const val contentFormat = "Content(%d):\n%s"
  const val encryptFormat = "Encrypted(%d):\n%s"
  const val decryptFormat = "Decrypted(%s):\n%s"
  const val signatureFormat = "Signature(%s):\n%s"
  const val certificateFormat = "DER(%d):\n%s\n\nPEM(b64:%d):\n%s\n%s"
}