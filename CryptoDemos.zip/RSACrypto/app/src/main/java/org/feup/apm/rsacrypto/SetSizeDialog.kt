package org.feup.apm.rsacrypto

import android.content.Context
import android.os.Bundle
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AppCompatDialog

typealias SetSizeListener = (Int) -> Unit

class SetSizeDialog(ctx: Context, private val initial: Int, val listener: SetSizeListener) : AppCompatDialog(ctx) {
  private val edtSize by lazy { findViewById<EditText>(R.id.edt_size)!! }
  private val btDone by lazy { findViewById<Button>(R.id.bt_done)!! }

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    setContentView(R.layout.dlg_set_size)
    with (edtSize) {
      setText(initial.toString())
      requestFocus()
    }
    window?.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE)    // show soft keyboard
    btDone.setOnClickListener {
      listener(edtSize.text.toString().toInt())
      dismiss()
    }
  }
}