These two demos implement some asymmetric cryptographic operations, with the keys generated inside
the Android Keystore. The private key never leaves the Keystore, and can only be used by the
same application on the smartphone that has created it.

RSA Crypto
==========
This app allows the generation of a RSA key pair with 512 bits of length (very short for today standards).
The RSA key size influences the size of signatures and encipherment (one block).
In the app we can generate a random array of bytes of specified size, to serve as input to other operations.
We can also see the generated keys (it is possible to see only the public key bytes).
We can perform a signature (with SHA-256 and RSA DSA) with private key, and verify it with the public key.
Flip a bit in the generated array of bytes, is also possible.
Finaly we can encrypt the input (with the private key), and decrypt the result.
In RSA, a direct encryption (and decryption) can only be performed to a value less than the key size.
For security in encryption a padding scheme should be used for inputs much less than the maximum size.
In this demo the standard PKCS1Padding is used.

EC Crypto
=========
This app generates an EC key pair using the curve named secp256r1 (aka the NIST P-256 curve)
The private key is a random value with 256 bits(p), and the public key is a Point Q = pG, where
G is called the generator point (associated with the curve).
This demo implements the same operations as the previous, without encryption and decryption.
The signature algorithm is ECDSA (with SHA-256).
Although there are standard algorithms for encryption with EC keys (e.g. ECIES), they involve
the derivation of a symmetric key. The Android Keystore does not implement yet EC encryption/decryption.