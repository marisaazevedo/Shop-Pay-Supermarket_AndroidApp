package org.feup.apm.standaloneservice

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.IBinder
import android.os.Process

class BackgroundService : Service() {
  private lateinit var notificationMgr: NotificationManager
  private lateinit var notificationChn: NotificationChannel
  private val myThreads = ThreadGroup("ServiceWorker")

  override fun onCreate() {
    super.onCreate()
    notificationMgr = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
    notificationChn = NotificationChannel("my_rem_service", "remote_service", NotificationManager.IMPORTANCE_DEFAULT)
    notificationMgr.createNotificationChannel(notificationChn)
    val notification = buildNotificationMessage("Remote Service is running")
    startForeground(1, notification)
    sendMessage("Service in onCreate()")
  }

  override fun onStartCommand(intent: Intent, flags: Int, startId: Int): Int {
    super.onStartCommand(intent, flags, startId)
    val counter = intent.extras?.getInt("counter") ?: 0
    sendMessage("onStartCommand(): counter = " + counter + ", startId = " + startId + ", tid = " + Process.myTid())
    Thread(myThreads, ServiceWorker(counter), "BackgroundService").start()
    return START_NOT_STICKY
  }

  internal inner class ServiceWorker(private val counter: Int) : Runnable {
    override fun run() {
      val tid = Process.myTid()
      // do background processing here...
      try {
        sendMessage("sleeping for 10 seconds. counter = $counter, tid = $tid")
        Thread.sleep(10000)
        sendMessage("... waking up ($counter)")
      } catch (e: InterruptedException) {
        sendMessage("... sleep interrupted ($counter)")
      }
    }
  }

  override fun onDestroy() {
    sendMessage("Service in onDestroy()")
    myThreads.interrupt()
    notificationMgr.cancelAll()
    super.onDestroy()
  }

  override fun onBind(intent: Intent): IBinder? {
    return null
  }

  private fun buildNotificationMessage(message: String): Notification {
    val contentIntent = PendingIntent.getActivity(this, 0, Intent("org.feup.apm.intents.serviceactivity"),
      PendingIntent.FLAG_IMMUTABLE)
    val notification: Notification = Notification.Builder(this, notificationChn.id)
      .setSmallIcon(R.drawable.ic_notification)
      .setContentTitle("Remote Service")
      .setContentText(message)
      .setContentIntent(contentIntent)
      .build()
    notification.flags = Notification.FLAG_NO_CLEAR
    return notification
  }

  private fun sendMessage(message: String) {
    val intent = Intent("apm.intents.RCV_MESS")
    intent.putExtra("message", message)
    sendBroadcast(intent)
  }
}
