Demos with Android Started Services
===================================

AndroidStartedService and StandAloneService

AndroidStartedService has an Activity that invokes a service through an intent and the starService() method. The application contains a local service component that can be invoked that way. The Activity can also invoke another service in another application using startForegroundService() instead of startService(). (after API 26 inclusive, for remote started services only startForegroundService() is supported, which is used here).
The local service or the remote one are selected by a radio button.

StandAloneService contains the remote service called by the activity in AndroidStartedService.
See the AndroidStartedService activity messages generated in the code of the client and the service.
Only for the purpose of transmitting such status messages from the remote service, the StandAloneService sends broadcasts to a broadcast receiver registered dynamically on the client Activity (AndroidStartedService) with an action definition to invoke it.
We are calling the remote service using startForegroundService(). The call startService() could be used only if the target API level was API 25. The call to startForegroundService() invoke also onStartCommand(). On the remote service, it is mandatory to call the service method startForeground(), that must display a Notification (it could be done in onCreate() or in onStartCommand()). Our service shows a notification while the servive is running.

Other restrictions: After API 26 other restrictions have been imposed on started services to be called from other applications. So, this type of services were designed for beeing defined and called in the same app, from the foreground Activity.
Nevertheless, if complying to all the conditions imposed by Android it is still possible to define and invoke a Started Service in a Standalone app (containing only the service).
Some Conditions: The invoking app should acquire the permission QUERY_ALL_PACKAGES to be able to find the service (it should use an intent specifying package/class). Foregroung services (started sevices with startForegroundService()), must have a type declared in a manifest attribute of the service).
The manifest for those services, must acquire some permissions:
  .POST_NOTIFICATIONS (usually also requires the user agreement in the Android Settings app).
  .SYSTEM_ALERT_WINDOW (this is a permission that requires user explicit agreement; it could be set on the system Settings app, in the Apps &   Notifications category, finding the app with the service, and allowing 'Display over other apps').
  .FOREGROUND_SERVICE
  . and usually a permission for the service type declared in the manifest (I use FOREGROUND_SERVICE_REMOTE_MESSAGING).
