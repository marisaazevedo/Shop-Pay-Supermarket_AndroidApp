package org.feup.apm.androidstartedservice

import android.content.*
import android.graphics.Color
import android.os.Bundle
import android.os.Process
import android.view.View
import android.widget.Button
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.TextView
import androidx.activity.SystemBarStyle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {
  companion object {
    lateinit var activity: MainActivity
  }

  private var counter = 1
  private lateinit var receiver: BroadcastReceiver
  private val toolbar by lazy { findViewById<Toolbar>(R.id.toolbar) }
  private val rg by lazy { findViewById<RadioGroup>(R.id.radioGroup1) }
  private val console by lazy { findViewById<TextView>(R.id.tv_text) }
  private val scroll by lazy { findViewById<ScrollView>(R.id.scView) }
  private val btStart by lazy { findViewById<Button>(R.id.bt_start) }
  private val btStop by lazy { findViewById<Button>(R.id.bt_stop) }
  private val btClear by lazy { findViewById<Button>(R.id.bt_clear) }

  public override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge(navigationBarStyle = SystemBarStyle.light(Color.TRANSPARENT, Color.TRANSPARENT))
    setStatusBarIconColor(window, Lightness.LIGHT)
    setContentView(R.layout.activity_main)
    setSupportActionBar(toolbar)
    setInsetsPadding(toolbar, top=dpToPx(-8f))
    rg.setOnCheckedChangeListener {
      _: RadioGroup, id: Int -> if (id == R.id.radio0)
          stopService(R.id.radio1)
        else
          stopService(R.id.radio0)
    }
    btStart.setOnClickListener { doButtonClick(it) }
    btStop.setOnClickListener { doButtonClick(it) }
    btClear.setOnClickListener { doButtonClick(it) }

    receiver = object : BroadcastReceiver() {
      override fun onReceive(context: Context, intent: Intent) {
        val message = intent.getStringExtra("message") ?: ""
        addText(message)
      }
    }
    activity = this
  }

  override fun onResume() {
    super.onResume()
    val intentFilter = IntentFilter("apm.intents.RCV_MESS")
    ContextCompat.registerReceiver(this, receiver, intentFilter, ContextCompat.RECEIVER_EXPORTED)
  }

  override fun onPause() {
    super.onPause()
    unregisterReceiver(receiver)
  }

  fun addText(text: String) {
    val newText = "${console.text}\n$text"
    console.text = newText
    scroll.fullScroll(ScrollView.FOCUS_DOWN)
  }

  private fun doButtonClick(view: View) {
    when (view.id) {
      R.id.bt_start -> {
        addText("Call service #" + counter + ", tid = " + Process.myTid())
        val intent = if (rg.checkedRadioButtonId == R.id.radio0)                        // Local service
          Intent(this, BackgroundService::class.java)
        else                                                                            // Remote service
          Intent().apply {
            component = ComponentName("org.feup.apm.standaloneservice", "org.feup.apm.standaloneservice.BackgroundService")
            addFlags(Intent.FLAG_INCLUDE_STOPPED_PACKAGES)
          }
        intent.putExtra("counter", counter++)
        if (rg.checkedRadioButtonId == R.id.radio0)
          startService(intent)
        else
          startForegroundService(intent)
      }
      R.id.bt_stop -> stopService(rg.checkedRadioButtonId)
      R.id.bt_clear -> {
        console.text = ""
        scroll.fullScroll(ScrollView.FOCUS_UP)
      }
    }
  }

  private fun stopService(id: Int) {
    val intent = if (id == R.id.radio0)                                  // Local service
      Intent(this, BackgroundService::class.java)
    else {                                                               // Remote service
      Intent().apply {
        component = ComponentName("org.feup.apm.standaloneservice", "org.feup.apm.standaloneservice.BackgroundService")
        addFlags(Intent.FLAG_INCLUDE_STOPPED_PACKAGES)
      }
    }
    addText("Call stop service")
    stopService(intent)
  }

  public override fun onDestroy() {
    super.onDestroy()
    stopService(rg.checkedRadioButtonId)
  }
}
