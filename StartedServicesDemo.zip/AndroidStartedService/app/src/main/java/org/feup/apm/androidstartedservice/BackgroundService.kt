package org.feup.apm.androidstartedservice

import android.app.*
import android.content.Intent
import android.os.IBinder
import android.os.Process

class BackgroundService : Service() {
  private lateinit var notificationMgr: NotificationManager
  private lateinit var notificationChn: NotificationChannel
  private lateinit var activity: MainActivity
  private val myThreads = ThreadGroup("ServiceWorker")

  override fun onCreate() {
    super.onCreate()
    notificationMgr = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
    notificationChn = NotificationChannel("MyChannel", "my_service_channel", NotificationManager.IMPORTANCE_DEFAULT)
    notificationMgr.createNotificationChannel(notificationChn)
    displayNotificationMessage("Local background service is running")
    activity = MainActivity.activity
    activity.addText("Service in onCreate()")
  }

  override fun onStartCommand(intent: Intent, flags: Int, startId: Int): Int {
    super.onStartCommand(intent, flags, startId)
    val counter = intent.extras?.getInt("counter") ?: 0
    activity.addText("onStartCommand(): counter = " + counter + ", startId = " + startId + ", tid = " + Process.myTid())
    Thread(myThreads, ServiceWorker(counter), "BackgroundService").start()
    return START_NOT_STICKY
  }

  override fun onDestroy() {
    activity.addText("Service in onDestroy()")
    myThreads.interrupt()
    notificationMgr.cancelAll()
    super.onDestroy()
  }

  override fun onBind(intent: Intent): IBinder? {
    return null
  }

  private fun displayNotificationMessage(message: String) {
    val contentIntent = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java),
      PendingIntent.FLAG_IMMUTABLE)
    val notification: Notification = Notification.Builder(this, notificationChn.id)
      .setSmallIcon(R.drawable.emo_im_winking)
      .setContentTitle("Local service")
      .setContentText(message)
      .setContentIntent(contentIntent)
      .build()
    notification.flags = Notification.FLAG_NO_CLEAR
    notificationMgr.notify(0, notification)
  }

  internal inner class ServiceWorker(private val counter: Int) : Runnable {
    override fun run() {
      val tid: Int
      // do background processing here...
      try {
        tid = Process.myTid()
        activity.runOnUiThread { activity.addText("sleeping for 10 seconds. counter = $counter, tid = $tid") }
        Thread.sleep(10000)
        activity.runOnUiThread { activity.addText("... waking up ($counter)") }
      } catch (e: InterruptedException) {
        activity.runOnUiThread { activity.addText("... sleep interrupted ($counter)") }
      }
    }
  }
}