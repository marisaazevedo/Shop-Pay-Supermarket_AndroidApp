package org.feup.apm.callhttp.co

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.*
import java.net.HttpURLConnection
import java.net.URL

private fun readStream(input: InputStream): String {
  var reader: BufferedReader? = null
  var line: String?
  val response = StringBuilder()
  try {
    reader = BufferedReader(InputStreamReader(input))
    while (reader.readLine().also{ line = it } != null)
      response.append(line)
  }
  catch (e: IOException) {
    response.clear()
    response.append("readStream: ${e.message}")
  }
  reader?.close()
  return response.toString()
}

//**************************************************************************
// Function to call REST operation GetUsers
suspend fun getUsers(act: MainActivity, baseAddress: String, port: Int): String {
  val urlRoute = "/users"
  val url = URL("http://$baseAddress:$port$urlRoute")
  act.setResponse("GET ${url.toExternalForm()}")

  return withContext(Dispatchers.IO) {
    var result: String
    var urlConnection: HttpURLConnection? = null
    try {
      urlConnection = (url.openConnection() as HttpURLConnection).apply {
        doInput = true
        setRequestProperty("Content-Type", "application/json")
        useCaches = false
        connectTimeout = 5000
        result = if (responseCode == 200)
          readStream(inputStream)
        else
          "Code: $responseCode"
      }
    } catch (e: Exception) {
      result = e.toString()
    }
    urlConnection?.disconnect()
    result
  }
}

//**************************************************************************
// Function to call REST operation GetUser
suspend fun getUser(act: MainActivity, baseAddress: String, port: Int, userId: String): String {
  val urlRoute = "/users"
  val url = URL("http://$baseAddress:$port$urlRoute/$userId")
  act.setResponse("GET ${url.toExternalForm()}")

  return withContext(Dispatchers.IO) {
    var result: String
    var urlConnection: HttpURLConnection? = null
    try {
      urlConnection = (url.openConnection() as HttpURLConnection).apply {
        doInput = true
        setRequestProperty("Content-Type", "application/json")
        useCaches = false
        connectTimeout = 5000
        result = if (responseCode == 200)
          readStream(inputStream)
        else
          "Code: $responseCode"
      }
    } catch (e: Exception) {
      result = e.toString()
    }
    urlConnection?.disconnect()
    result
  }
}

//**************************************************************************
// Function to call REST operation AddUser
suspend fun addUser(act: MainActivity, baseAddress: String, port: Int, userName: String): String {
  val urlRoute = "/users"
  val url = URL("http://$baseAddress:$port$urlRoute")
  val payload = "\"$userName\""

  act.setResponse("POST ${url.toExternalForm()}")
  act.appendResponse("Payload: $payload")

  return withContext(Dispatchers.IO) {
    var urlConnection: HttpURLConnection? = null
    var result: String
    try {
      urlConnection = (url.openConnection() as HttpURLConnection).apply {
        doOutput = true
        doInput = true
        requestMethod = "POST"
        setRequestProperty("Content-Type", "application/json")
        useCaches = false
        connectTimeout = 5000
        with(outputStream) {
          write(payload.toByteArray())
          flush()
          close()
        }
        // get response
        result = if (responseCode == 200)
          readStream(inputStream)
        else
          "Code: $responseCode"
      }
    } catch (e: Exception) {
      result = e.toString()
    }
    urlConnection?.disconnect()
    result
  }
}

//**************************************************************************
// Function to call REST operation DeleteUser
suspend fun delUser(act: MainActivity, baseAddress: String, port: Int, userId: String): String {
  val urlRoute = "/users"
  val url = URL("http://$baseAddress:$port$urlRoute/$userId")
  act.setResponse("DELETE ${url.toExternalForm()}")

  return withContext(Dispatchers.IO) {
    var result: String
    var urlConnection: HttpURLConnection? = null
    try {
      urlConnection = (url.openConnection() as HttpURLConnection).apply {
        requestMethod = "DELETE"
        setRequestProperty("Content-Type", "application/json")
        useCaches = false
        connectTimeout = 5000
        // get response
        result = "Code: $responseCode"
      }
    } catch (e: Exception) {
      result = e.toString()
    }
    urlConnection?.disconnect()
    result
  }
}

//**************************************************************************
// Function to call REST operation ChangeUser
suspend fun chUser(act: MainActivity, baseAddress: String, port: Int, userId: String, userName: String): String {
  val urlRoute = "/users"
  val url = URL("http://$baseAddress:$port$urlRoute/$userId")
  val payload = "\"$userName\""
  act.setResponse("PUT ${url.toExternalForm()}")
  act.appendResponse("Payload: $payload")

  return withContext(Dispatchers.IO) {
    var result: String
    var urlConnection: HttpURLConnection? = null
    try {
      urlConnection = (url.openConnection() as HttpURLConnection).apply {
        doOutput = true
        doInput = true
        requestMethod = "PUT"
        setRequestProperty("Content-Type", "application/json")
        useCaches = false
        connectTimeout = 5000

        with(outputStream) {
          write(payload.toByteArray())
          flush()
          close()
        }

        // get response
        result = if (responseCode == 200)
          readStream(inputStream)
        else
          "Code: $responseCode"
      }
    } catch (e: Exception) {
        result = e.toString()
    }
    urlConnection?.disconnect()
    result
  }
}
