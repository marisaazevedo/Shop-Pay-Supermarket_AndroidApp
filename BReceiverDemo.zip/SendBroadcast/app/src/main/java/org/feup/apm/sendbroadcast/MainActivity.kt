package org.feup.apm.sendbroadcast

import android.content.ComponentName
import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
  val tv by lazy { findViewById<TextView>(R.id.tv_text) }

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    setContentView(R.layout.activity_main)
  }

  override fun onCreateOptionsMenu(menu: Menu?): Boolean {
    menuInflater.inflate(R.menu.menu_main, menu)         // read the menu resource
    return true
  }

  override fun onOptionsItemSelected(item: MenuItem): Boolean {
    appendMenuItemText(item)
    return when (item.itemId) {
      R.id.menu_clear -> {
        emptyText()
        true
      }
      R.id.menu_send_broadcast -> {
        sendABroadcast()
        true
      }
      else -> super.onOptionsItemSelected(item)
    }
  }

  private fun appendMenuItemText(menuItem: MenuItem) {
    val newValue ="${tv.text}${menuItem.title}\n"
    tv.text = newValue
  }

  private fun emptyText() {
    tv.text = ""
  }

  private fun sendABroadcast() {
    //Create an intent with a class component
    val brIntent = Intent().apply {
      component = ComponentName("org.feup.apm.standalonereceiver", "org.feup.apm.standalonereceiver.StandAloneReceiver")
      addFlags(Intent.FLAG_INCLUDE_STOPPED_PACKAGES)               // for custom standalone BRs
      putExtra("message", "Alert! Click to dial.")
    }
    //send out the broadcast
    sendBroadcast(brIntent)
  }
}