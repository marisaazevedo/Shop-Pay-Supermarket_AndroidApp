Demos with Brodacast Receivers
==============================

StandAloneReceiver and SendBroadcast
------------------------------------

StandAloneReceiver contains a broadcast receiver that creates a notification when it executes.
Prior to Android API level 12 all broadcast receivers could be invoked even if their processes have never been started. After API level 12, broadcast receivers associated to custom intents (or directly called), require that the process where the BR belongs to, has executed at least once (passing the process from a STOPPED/INSTALLED state to a STARTED state). In order to garantee that, the app that contains a broadcast receiver can contain another Activity that will make the broadcast receiver operational (after that activity had runned at least once).
In standalone receivers (apps that contain only a broadcast receiver without activities), it is also possible to specify (with an additional flag in the intent) that never STARTED processes should also be considered, which SendBroadcast does when it sends the broadacast.
SendBroadcast generates a broadcast intent to the previous broadcast receiver using a menu item. The broadcast receiver creates a notification associated with a pending intent (with action ACTION_DIAL) starting the dial application when clicked.

After API 26, calling Broadcast Receivers between different applications (targetting an API >= 26) is only possible knowing the package and class name of the BR (except for OS broadcasts), and be in the intent to start them. Scheduled jobs partially replaced that functionality.

Note: Android Studio produces a message saying that there was a failure installing an application without Activities. Nevertheless, the application is installed (without being STARTED). You can see it in the Settings, and displaying the full list of apps on the device.

The app needs the POST_NOTIFICATIONS permission, and that setting in the general Settings.
