package org.feup.apm.standalonereceiver

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class StandAloneReceiver : BroadcastReceiver() {
  override fun onReceive(ctx: Context, intent: Intent) {
    sendNotification(ctx, intent.getStringExtra("message"))
  }

  private fun sendNotification(ctx: Context, message: String?) {
    //Get the notification manager
    val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    //Create a notification channel (required after API 26)
    val nc = NotificationChannel("BRChannel", "myBrChannel", NotificationManager.IMPORTANCE_HIGH)
    nm.createNotificationChannel(nc)
    // Intent associated to the notification (triggered when the user clicks the notification)
    val intent = Intent(Intent.ACTION_DIAL)
    val pi = PendingIntent.getActivity(ctx, 0, intent, PendingIntent.FLAG_IMMUTABLE)

    //Create Notification Object
    val notification: Notification = Notification.Builder(ctx, nc.id)
      .setSmallIcon(R.drawable.robot)
      .setContentIntent(pi)
      .setContentTitle("From Me")
      .setContentText(message)
      .build()
    //Send notification
    nm.notify(1, notification)
  }
}