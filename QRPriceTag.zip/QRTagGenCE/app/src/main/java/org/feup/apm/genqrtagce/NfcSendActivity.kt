package org.feup.apm.genqrtagce

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.activity.SystemBarStyle
import androidx.activity.enableEdgeToEdge
import androidx.localbroadcastmanager.content.LocalBroadcastManager

class NfcSendActivity : AppCompatActivity() {
  private val broadcastReceiver = object: BroadcastReceiver() {   // intersects event generated when the NFC connection is broken
    override fun onReceive(ctx: Context, intent: Intent) {
      Toast.makeText(this@NfcSendActivity, "NFC link lost", Toast.LENGTH_LONG).show()
      finish()
    }
  }

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge(navigationBarStyle = SystemBarStyle.light(Color.TRANSPARENT, Color.TRANSPARENT))
    setContentView(R.layout.activity_nfcsend)
  }

  override fun onResume() {
    super.onResume()
    Card.enabled = true    // allow card emulation to respond to commands (on CertCardService)
    val intentFilter = IntentFilter(Constants.ACTION_CARD_DONE)
    LocalBroadcastManager.getInstance(applicationContext).registerReceiver(broadcastReceiver, intentFilter)
  }

  override fun onPause() {
    super.onPause()
    Card.enabled = false    // disallow card emulation to respond to commands (on CertCardService)
    LocalBroadcastManager.getInstance(applicationContext).unregisterReceiver(broadcastReceiver)
  }
}