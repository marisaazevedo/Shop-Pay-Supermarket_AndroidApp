package org.feup.apm.genqrtagce

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.activity.SystemBarStyle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import java.math.BigInteger
import java.nio.ByteBuffer
import java.nio.charset.StandardCharsets
import java.security.KeyPairGenerator
import java.security.KeyStore
import java.security.PrivateKey
import java.security.PublicKey
import java.security.cert.X509Certificate
import java.security.interfaces.RSAPublicKey
import java.util.*
import javax.crypto.Cipher
import javax.security.auth.x500.X500Principal

/* Utility top-level function */
fun byteArrayToHex(ba: ByteArray): String {
  val sb = StringBuilder(ba.size * 2)
  for (b in ba) sb.append(String.format("%02x", b))
  return sb.toString()
}

fun hexStringToByteArray(s: String): ByteArray {
  val data = ByteArray(s.length / 2)
  var k = 0
  while (k < s.length) {
    data[k/2] = ((Character.digit(s[k], 16) shl 4) + Character.digit(s[k+1], 16)).toByte()
    k += 2
  }
  return data
}

class MainActivity : AppCompatActivity() {
  private val appTag = "GenProductTag"
  private var hasKey = false
  private var encTag: ByteArray? = null
  private var pri: PrivateKey? = null
  private var pub: PublicKey? = null
  private var productUUID = UUID(0L, 0L)
  private var entry: KeyStore.PrivateKeyEntry? = null
    get() {
      if (field == null)
        field = KeyStore.getInstance(Constants.ANDROID_KEYSTORE).run {
          load(null)
          getEntry(Constants.keyname, null) as KeyStore.PrivateKeyEntry?
        }
      return field
    }

  private val toolbar by lazy { findViewById<Toolbar>(R.id.toolbar) }
  private val edUUID by lazy { findViewById<EditText>(R.id.ed_uuid) }
  private val edName by lazy { findViewById<EditText>(R.id.ed_name) }
  private val edEuros by lazy { findViewById<EditText>(R.id.ed_euros) }
  private val edCents by lazy { findViewById<EditText>(R.id.ed_cents) }
  private val tvNoKey by lazy { findViewById<TextView>(R.id.tv_nokey) }
  private val tvKey by lazy { findViewById<TextView>(R.id.tv_pubkey) }
  private val btSend by lazy { findViewById<Button>(R.id.bt_send) }
  private val btShowKey by lazy { findViewById<Button>(R.id.bt_showkey) }
  private val btGenKey by lazy { findViewById<Button>(R.id.bt_genkey) }
  private val btGenTag by lazy { findViewById<Button>(R.id.bt_gentag) }
  private val btDecTag by lazy { findViewById<Button>(R.id.bt_dectag) }
  private val btUUIDGen by lazy { findViewById<Button>(R.id.bt_ugen) }

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge(navigationBarStyle = SystemBarStyle.light(Color.TRANSPARENT, Color.TRANSPARENT))
    setContentView(R.layout.activity_main)
    setStatusBarIconColor(window, Lightness.LIGHT)
    setSupportActionBar(toolbar)
    setInsetsPadding(toolbar, top = dpToPx(-8f))
    setInsetsPadding(tvKey, bottom=0)
    try {
      hasKey = entry != null
      if (hasKey) {
        pub = entry?.certificate?.publicKey
        pri = entry?.privateKey
        tvNoKey.text = ""
      }
    }
    catch (e: Exception) {
      hasKey = false
    }
    btGenKey.apply {
      setOnClickListener { genKeys() }
      isEnabled = !hasKey
    }
    btShowKey.apply {
      setOnClickListener { showKey() }
      isEnabled = hasKey
    }
    btSend.apply {
      setOnClickListener { sendKey() }
      isEnabled = hasKey
    }
    btGenTag.setOnClickListener { genTag() }
    btDecTag.setOnClickListener { decodeTag() }
    btUUIDGen.setOnClickListener {
      productUUID = UUID.randomUUID()
      edUUID.setText(productUUID.toString())
    }
  }

  private fun genTag() {
    var name = edName.text.toString()
    if (!hasKey || edUUID.text.toString().isEmpty() || name.isEmpty() || edEuros.text.toString().isEmpty() || edCents.text.toString().isEmpty()) {
      tvNoKey.setText(R.string.msg_empty)
      return
    }

    if (name.length > 29)
      name = name.substring(0, 29)
    val len = 4 + 16 + 2 + 1 + 1 + name.length  // length of (tagID, UUID, euros(short), cents(byte), nr_bytes(name)(byte), name)
    val tag = ByteBuffer.allocate(len).apply {  // building an array of bytes (binary)
      putInt(Constants.tagId)
      putLong(productUUID.mostSignificantBits)
      putLong(productUUID.leastSignificantBits)
      putShort(edEuros.text.toString().toShort())
      put(edCents.text.toString().toByte())
      put(name.length.toByte())
      put(name.toByteArray(StandardCharsets.ISO_8859_1))   // 1 byte per char without code translation
    }
    try {
      encTag = Cipher.getInstance(Constants.ENC_ALGO).run {
        init(Cipher.ENCRYPT_MODE, pri)
        doFinal(tag.array())
      }
      tvKey.text = resources.getString(R.string.msg_enctag, encTag!!.size, byteArrayToHex(encTag!!))
      tvNoKey.text = ""
    }
    catch (e: Exception) {
      tvNoKey.text = e.message
    }
    startActivity(Intent(this, QRTagActivity::class.java).apply {
      putExtra("data", encTag)
    })
  }

  private fun decodeTag() {
    val clearTextTag: ByteArray
    if (encTag == null || encTag!!.isEmpty()) {
      tvNoKey.setText(R.string.msg_notag)
      return
    }
    try {
      clearTextTag = Cipher.getInstance(Constants.ENC_ALGO).run {
        init(Cipher.DECRYPT_MODE, pub)
        doFinal(encTag)
      }
    }
    catch (e: Exception) {
      tvNoKey.text = e.message
      return
    }
    val tag = ByteBuffer.wrap(clearTextTag)
    val tId = tag.int
    val id = UUID(tag.long, tag.long)
    val euros = tag.short.toInt()
    val cents = tag.get().toInt()
    val bName = ByteArray(tag.get().toInt())
    tag[bName]
    val name = String(bName, StandardCharsets.ISO_8859_1)
    val strCents = String.format(Locale.ENGLISH, "%02d", cents)
    val text = """
      DecTag (${clearTextTag.size}):
      ${byteArrayToHex(clearTextTag)}
           
      ${if (tId == Constants.tagId) "correct" else "wrong"}
      ID: $id
      Name: $name
      Price: €$euros.$strCents
    """.trimIndent()
    tvNoKey.text = ""
    tvKey.text = text
  }

  private fun genKeys() {
    try {
      val spec = KeyGenParameterSpec.Builder(Constants.keyname,
        KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT or
                 KeyProperties.PURPOSE_SIGN or KeyProperties.PURPOSE_VERIFY)
        .setKeySize(Constants.KEY_SIZE)
        .setDigests(KeyProperties.DIGEST_NONE, KeyProperties.DIGEST_SHA256)
        .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_RSA_PKCS1)
        .setSignaturePaddings(KeyProperties.SIGNATURE_PADDING_RSA_PKCS1)
        .setCertificateSubject(X500Principal("CN=" + Constants.keyname))           // for the certificate containing the public key
        .setCertificateSerialNumber(BigInteger.valueOf(Constants.CERT_SERIAL.toLong()))  // some serial number ...
        .setCertificateNotBefore(GregorianCalendar().time)
        .setCertificateNotAfter(GregorianCalendar().apply { add(Calendar.YEAR, 10) }.time)
        .build()
      KeyPairGenerator.getInstance(Constants.KEY_ALGO, Constants.ANDROID_KEYSTORE).run {
        initialize(spec)
        generateKeyPair()
      }
      pri = entry?.privateKey                      // private key in a class (PrivateKey) --> references the Android Keystore
      pub = entry?.certificate?.publicKey          // the corresponding public key in a class (PublicKey)
      hasKey = true
    }
    catch (e: Exception) {
      tvNoKey.text = e.message
      return
    }
    btSend.isEnabled = hasKey
    btShowKey.isEnabled = hasKey
    btGenKey.isEnabled = !hasKey
    tvNoKey.text = ""
    val modulus = (pub as RSAPublicKey).modulus.toByteArray()
    val text = """
      Modulus (${modulus.size}):
           
      ${byteArrayToHex(modulus)}
           
      Public Exponent:
    
      ${byteArrayToHex((pub as RSAPublicKey).publicExponent.toByteArray())}
           
    """.trimIndent()
    tvKey.text = text
  }

  private fun sendKey() {
    val cert = entry?.certificate as X509Certificate
    tvKey.text = cert.toString()
    startActivity(Intent(this, NfcSendActivity::class.java))
  }

  private fun showKey() {
    val cert = entry?.certificate as X509Certificate
    val encCert = cert.encoded
    val strCert = cert.toString()
    val b64Cert = Base64.encodeToString(encCert, Base64.DEFAULT)
    val outText = "cert(${encCert.size}): ${byteArrayToHex(encCert)}\n\ncert(b64): $b64Cert\n$strCert"
    tvKey.text = outText
    Log.d(appTag, "-----BEGIN CERTIFICATE-----\n$b64Cert-----END CERTIFICATE-----\n")
  }
}