package org.feup.apm.genqrtagce

object Constants {
    const val ANDROID_KEYSTORE = "AndroidKeyStore"
    const val KEY_SIZE = 512
    const val KEY_ALGO = "RSA"
    const val CERT_SERIAL = 12121212
    const val ENC_ALGO = "RSA/NONE/PKCS1Padding"
    const val keyname = "AcmeKey"
    const val tagId = 0x41636D65                  // equal to "Acme"
    const val ACTION_CARD_DONE = "CMD_PROCESSING_DONE"
}