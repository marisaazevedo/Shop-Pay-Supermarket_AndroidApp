package org.feup.apm.readqrtagce

import android.graphics.Color
import android.nfc.NfcAdapter
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.TextView
import androidx.activity.SystemBarStyle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import com.journeyapps.barcodescanner.ScanContract
import com.journeyapps.barcodescanner.ScanOptions
import java.io.ByteArrayInputStream
import java.nio.ByteBuffer
import java.nio.charset.StandardCharsets
import java.security.KeyStore
import java.security.PublicKey
import java.security.cert.CertificateFactory
import java.security.cert.X509Certificate
import java.security.interfaces.RSAPublicKey
import java.util.*
import javax.crypto.Cipher

/* Utility top-level function */
fun byteArrayToHex(ba: ByteArray): String {
  val sb = StringBuilder(ba.size * 2)
  for (b in ba) sb.append(String.format("%02x", b))
  return sb.toString()
}

fun hexStringToByteArray(s: String): ByteArray {
  val data = ByteArray(s.length/2)
  var k = 0
  while (k < s.length) {
    data[k/2] = ((Character.digit(s[k], 16) shl 4) + Character.digit(s[k+1], 16)).toByte()
    k += 2
  }
  return data
}

const val READER_FLAGS = NfcAdapter.FLAG_READER_NFC_A or NfcAdapter.FLAG_READER_SKIP_NDEF_CHECK

class MainActivity : AppCompatActivity() {
  private var hasKey = false
  private var pub: PublicKey? = null
  private val nfc by lazy { NfcAdapter.getDefaultAdapter(this) }
  private val cardReader by lazy { CertReader(::showAndStoreKey) }

  private val toolbar by lazy { findViewById<Toolbar>(R.id.toolbar) }
  private val tvTitle by lazy { findViewById<TextView>(R.id.tv_title) }
  private val tvText by lazy { findViewById<TextView>(R.id.tv_text) }

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge(navigationBarStyle = SystemBarStyle.light(Color.TRANSPARENT, Color.TRANSPARENT))
    setStatusBarIconColor(window, Lightness.LIGHT)
    setContentView(R.layout.activity_main)
    setSupportActionBar(toolbar)
    setInsetsPadding(toolbar, top=dpToPx(-8f))
    setInsetsPadding(tvText, left=dpToPx(10f), right=dpToPx(10f), bottom=0)
    readKey()
  }

  override fun onResume() {
    super.onResume()
    nfc.enableReaderMode(this, cardReader, READER_FLAGS, null)
  }

  override fun onPause() {
    super.onPause()
    nfc.disableReaderMode(this)
  }

  override fun onCreateOptionsMenu(menu: Menu): Boolean {
    menuInflater.inflate(R.menu.activity_main, menu)
    return true
  }

  override fun onOptionsItemSelected(item: MenuItem): Boolean {
    if (item.itemId == R.id.mn_scan)
      scanQRCode()
    return true
  }

  private fun readKey() {
    try {
      val cert = KeyStore.getInstance(Constants.ANDROID_KEYSTORE).run {
        load(null)
        getCertificate(Constants.keyAlias)
      }
      if (cert != null) {
        pub = cert.publicKey
        hasKey = true
        tvTitle.setText(R.string.msg_keyinfo)
      }
    }
    catch (e: Exception) {
      tvTitle.text = e.message
    }
    if (hasKey) {
      tvText.text = pubKeyText()
    }
  }

  private fun showAndStoreKey(cert: ByteArray) {
    runOnUiThread {
      try {
        val x509 = CertificateFactory.getInstance("X509")
          .generateCertificate(ByteArrayInputStream(cert)) as X509Certificate
        KeyStore.getInstance(Constants.ANDROID_KEYSTORE).run {
          load(null)
          setEntry(Constants.keyAlias, KeyStore.TrustedCertificateEntry(x509), null)
        }
        pub = x509.publicKey
        hasKey = true
        tvTitle.setText(R.string.msg_keyinfo)
      }
      catch (e: Exception) {
        tvTitle.text = e.message
      }
      tvText.text = pubKeyText()
    }
  }

  private fun scanQRCode() {
    val options = ScanOptions().apply {
      setDesiredBarcodeFormats(ScanOptions.QR_CODE)
      setBeepEnabled(false)
      setOrientationLocked(true)
    }
    scanCodeLauncher.launch(options)
  }

  private val scanCodeLauncher = registerForActivityResult(ScanContract()) {
    if (it != null && it.contents != null) {
      val result = it.contents
      decodeAndShow(result.toByteArray(StandardCharsets.ISO_8859_1))
    }
  }

  private fun decodeAndShow(encTag: ByteArray) {
    val clearTextTag: ByteArray

    try {
      clearTextTag = Cipher.getInstance(Constants.ENC_ALGO).run {
        init(Cipher.DECRYPT_MODE, pub)
        doFinal(encTag)
      }
    } catch (e: Exception) {
      tvTitle.text = e.message
      return
    }
    val tag = ByteBuffer.wrap(clearTextTag)
    val tId = tag.int
    val id = UUID(tag.long, tag.long)
    val euros = tag.short.toInt()
    val cents = tag.get().toInt()
    val bName = ByteArray(tag.get().toInt())
    tag[bName]
    val name = String(bName, StandardCharsets.ISO_8859_1)
    val strCents = String.format("%02d", cents)
    tvTitle.setText(R.string.msg_taginfo)
    val textTag = """
      Read Tag (${clearTextTag.size}):
      ${byteArrayToHex(clearTextTag)}
           
      ${if (tId == Constants.tagId) "correct" else "wrong"}
      ID: $id
      Name: $name
      Price: €$euros.$strCents
    """.trimIndent()
    tvText.text = textTag
  }

  private fun pubKeyText(): String {
    return """
      Public Key:
      Modulus: ${byteArrayToHex((pub as RSAPublicKey).modulus.toByteArray())}
      Exponent: ${byteArrayToHex((pub as RSAPublicKey).publicExponent.toByteArray())}
    """.trimIndent()
  }
}
