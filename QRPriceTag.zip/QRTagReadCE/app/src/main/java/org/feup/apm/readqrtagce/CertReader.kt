package org.feup.apm.readqrtagce

import android.nfc.NfcAdapter
import android.nfc.Tag
import android.nfc.tech.IsoDep
import android.util.Log
import java.io.IOException

private const val CARD_AID = "F012233445"
private const val CMD_SEL_AID = "00A40400"
private const val CMD_GET_SECOND = "80010000"
private val RES_OK_SW = hexStringToByteArray("9000")

class CertReader(private val certListener: (ByteArray)->Unit) : NfcAdapter.ReaderCallback {
  override fun onTagDiscovered(tag: Tag) {
    val isoDep = IsoDep.get(tag)                    // Android smartcard reader emulator
    if (isoDep != null) {
      try {
        isoDep.connect()                            // establish a connection with the card and send 'select aid' command
        val result = isoDep.transceive(hexStringToByteArray(CMD_SEL_AID + String.format("%02X", CARD_AID.length/2) + CARD_AID))
        val rLen = result.size
        val status = byteArrayOf(result[rLen-2], result[rLen-1])
        val more = (result[0].toInt() == 1)
        if (RES_OK_SW.contentEquals(status)) {
          if (more) {
            val second = isoDep.transceive(hexStringToByteArray(CMD_GET_SECOND))
            val len = second.size
            if (RES_OK_SW.contentEquals(byteArrayOf(second[len-2], second[len-1])))
              certListener(result.sliceArray(1..rLen-3) + second.sliceArray(0..len-3))
          }
          else
            certListener(result.sliceArray(1..rLen-3))
        }
      }
      catch (e: IOException) {
        Log.e("CardReader", "Error communicating with card: $e")
      }
    }
  }
}