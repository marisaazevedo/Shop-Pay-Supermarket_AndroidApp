A pair of applications to generate and read a QR code containing a price tag for the supermarket project.
The QR code generated and presented contains a unique ID (UUID) that can also be randomly generated in the app,
a string description (with a maximum of 29 characters, and truncated if more), and the price in Euros and Cents
(a short for Euros, a byte for Cents).
The QR-code represents the encryption of the described information, with a prefix of 'Acme', for authenticity.
It generates and uses a pair of 512-bit RSA keys in the Android Keystore. The public key (in a certificate) can
be transmited via NFC (and card emulation) to another app.

QRTagGen
========
The generator application that display the tag (QR-code) and transmits the public key.

QRTagRead
=========
The reader application that can capture and decode de price tag (from a QR-code), and receive the public key
using NFC (and card reader) from the generator app.