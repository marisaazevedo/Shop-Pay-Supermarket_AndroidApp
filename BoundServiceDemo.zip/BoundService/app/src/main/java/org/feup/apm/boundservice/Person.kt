package org.feup.apm.boundservice

import android.os.Parcel
import android.os.Parcelable
import android.os.Parcelable.Creator

class Person() : Parcelable {
  var age = 0
  var name: String = ""

  private constructor(input: Parcel) : this() {
    readFromParcel(input)
  }

  override fun describeContents(): Int {
    return 0
  }

  override fun writeToParcel(output: Parcel, flags: Int) {
    output.writeInt(age)
    output.writeString(name)
  }

  fun readFromParcel(input: Parcel) {
    age = input.readInt()
    name = input.readString().toString()
  }

  companion object {
    @JvmField
    val CREATOR: Creator<Person> = object : Creator<Person> {
      override fun createFromParcel(input: Parcel): Person {
        return Person(input)
      }

      override fun newArray(size: Int): Array<Person?> {
        return arrayOfNulls(size)
      }
    }
  }
}