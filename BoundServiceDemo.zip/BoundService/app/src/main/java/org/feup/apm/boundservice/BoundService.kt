package org.feup.apm.boundservice

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.Process
import android.os.RemoteException
import android.os.IBinder

class BoundService : Service() {
  private lateinit var notificationMgr: NotificationManager
  private lateinit var notificationChn: NotificationChannel

  inner class BoundServiceImpl : IBoundService.Stub() {
    override fun getQuoteLong(ticker: String, requester: Person, response: IBoundServiceResponse) {
      var result = ""

      sendMessage("Long service call (" + Process.myTid() + ")")
      try {
        Thread.sleep(10000)
      }
      catch (e: InterruptedException) {
        result = "Interrupted Exception"
      }
      if (result.isEmpty())
        result = "Hello ${requester.name} (${requester.age} years old)! Quote for $ticker is $25.00"
      response.onQuoteResult(result)
    }
  }

  override fun onCreate() {
    super.onCreate()
    notificationMgr = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
    notificationChn = NotificationChannel("My_Bound_Service", "boundService", NotificationManager.IMPORTANCE_DEFAULT)
    notificationMgr.createNotificationChannel(notificationChn)
    displayNotificationMessage("Bound service created")
    sendMessage("onCreate() called (${Process.myTid()})")
  }

  override fun onBind(intent: Intent): IBinder {
    sendMessage("onBind() called (${Process.myTid()})")
    return BoundServiceImpl()
  }


  override fun onDestroy() {
    // Clear all notifications from this service
    super.onDestroy()
    notificationMgr.cancelAll()
    sendMessage("onDestroy() called (${Process.myTid()})")
  }

  private fun displayNotificationMessage(message: String) {
    val contentIntent = PendingIntent.getActivity(this, 0, Intent("apm.intents.ACTION_BOUND_CLIENT"), PendingIntent.FLAG_IMMUTABLE)
    val notification: Notification = Notification.Builder(this, notificationChn.id)
      .setSmallIcon(R.drawable.ic_service)
      .setContentTitle("StockQuoteService")
      .setContentText(message)
      .setContentIntent(contentIntent)
      .build()
    notification.flags = Notification.FLAG_NO_CLEAR
    notificationMgr.notify(1, notification)
  }

  private fun sendMessage(message: String) {
    val intent = Intent("apm.intents.BOUND_CLIENT_MESSAGE")
    intent.putExtra("message", message)
    sendBroadcast(intent)
  }
}