package org.feup.apm.boundclient

import android.content.*
import android.graphics.Color
import android.os.Bundle
import android.os.IBinder
import android.os.Process
import android.os.RemoteException
import android.widget.Button
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.SystemBarStyle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import org.feup.apm.boundservice.IBoundService
import org.feup.apm.boundservice.IBoundServiceResponse
import org.feup.apm.boundservice.Person

class MainActivity : AppCompatActivity() {
  private lateinit var receiver: BroadcastReceiver
  private lateinit var boundService: IBoundService
  private val toolbar by lazy { findViewById<Toolbar>(R.id.toolbar) }
  private val console by lazy { findViewById<TextView>(R.id.textView) }
  private val scroll by lazy { findViewById<ScrollView>(R.id.scView) }
  private val btClear by lazy { findViewById<Button>(R.id.bt_clear) }
  private val btBind by lazy { findViewById<Button>(R.id.bindBtn) }
  private val btCall by lazy { findViewById<Button>(R.id.callBtn) }
  private val btUnbind by lazy { findViewById<Button>(R.id.unbindBtn) }

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge(navigationBarStyle = SystemBarStyle.light(Color.TRANSPARENT, Color.TRANSPARENT))
    setStatusBarIconColor(window, Lightness.LIGHT)
    setContentView(R.layout.activity_main)
    setSupportActionBar(toolbar)
    setInsetsPadding(toolbar, top=dpToPx(-8f))
    btClear.setOnClickListener { console.text = "" }
    btBind.setOnClickListener {
      val intent = Intent().apply {
        component = ComponentName("org.feup.apm.boundservice", "org.feup.apm.boundservice.BoundService")
      }
      if (bindService(intent, servConn, BIND_AUTO_CREATE)) {
        btBind.isEnabled = false
        btUnbind.isEnabled = true
      }
    }
    btCall.setOnClickListener { callService() }
    btCall.isEnabled = false
    btUnbind.setOnClickListener {
      unbindService(servConn)
      btBind.isEnabled = true
      btCall.isEnabled = false
      btUnbind.isEnabled = false
      addText("call unbind (${Process.myTid()})")
    }
    btUnbind.isEnabled = false

    receiver = object : BroadcastReceiver() {
      override fun onReceive(context: Context, intent: Intent) {
        val message = intent.getStringExtra("message") ?: ""
        addText(message)
      }
    }
    addText("Activity tid: ${Process.myTid()}")
  }

  override fun onResume() {
    super.onResume()
    val intentFilter = IntentFilter("apm.intents.BOUND_CLIENT_MESSAGE")
    registerReceiver(receiver, intentFilter, RECEIVER_EXPORTED)
  }

  override fun onPause() {
    super.onPause()
    unregisterReceiver(receiver)
  }

  override fun onDestroy() {
    super.onDestroy()
    unbindService(servConn)
    addText("call unbind (${Process.myTid()})")
  }

  private fun callService() {
    try {
      val person = Person()
      person.age = 35
      person.name = "Dave"
      boundService.getQuoteLong("IBM", person, responseListener)
      addText("call service")
    }
    catch (re: RemoteException) {
      addText(re.message ?: "")
    }
  }

  private fun addText(txt: String) {
    val old = console.text.toString()
    val new = "${if(old.isEmpty()) "" else "$old\n"}$txt"
    console.text = new
    scroll.fullScroll(ScrollView.FOCUS_DOWN)
  }

  private val servConn: ServiceConnection = object : ServiceConnection {
    override fun onServiceConnected(name: ComponentName, service: IBinder) {
      addText("onServiceConnected() called (${Process.myTid()})")
      boundService = IBoundService.Stub.asInterface(service)
      btCall.isEnabled = true
    }

    override fun onServiceDisconnected(name: ComponentName) {
      addText("onServiceDisconnected() called")
      btBind.isEnabled = true
      btCall.isEnabled = false
      btUnbind.isEnabled = false
    }
  }

  private val responseListener: IBoundServiceResponse = object : IBoundServiceResponse.Stub() {
    override fun onQuoteResult(result: String) {
      val tid = Process.myTid()
      runOnUiThread {
        addText("callback called ($tid)")
        addText(result)
        Toast.makeText(this@MainActivity, "Value from service is \"$result\"", Toast.LENGTH_LONG).show()
      }
    }
  }
}