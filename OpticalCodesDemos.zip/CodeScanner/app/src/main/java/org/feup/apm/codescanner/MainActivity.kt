package org.feup.apm.codescanner

import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.SystemBarStyle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.widget.Toolbar
import com.journeyapps.barcodescanner.ScanContract
import com.journeyapps.barcodescanner.ScanOptions

fun byteArrayToHex(ba: ByteArray): String {
  val sb = StringBuilder(ba.size * 2)
  for (b in ba) sb.append(String.format("%02x", b))
  return sb.toString()
}

class MainActivity : AppCompatActivity() {
  private val toolbar by lazy { findViewById<Toolbar>(R.id.toolbar) }
  private val llResult by lazy { findViewById<LinearLayout>(R.id.ll_result) }
  private val btScanQR by lazy { findViewById<Button>(R.id.bt_scan_qr) }
  private val btScanBar by lazy { findViewById<Button>(R.id.bt_scan_bar) }
  private val tvResult by lazy { findViewById<TextView>(R.id.tv_message) }
  private val tvHex by lazy { findViewById<TextView>(R.id.tv_hex) }
  private val tvAltUTF by lazy { findViewById<TextView>(R.id.tv_alt_message) }

  // New way to define a call to startActivityForResult, passing a callback, replacing the override to onResult()
  // ScanContract and ScanOptions come from the external library
  //     com.journeyapps:zxing-android-embedded
  // The library includes an Activity to perform the scan (the result is a String)
  private val scanCodeLauncher = registerForActivityResult(ScanContract()) {
    if (it != null && it.contents != null) {
      val result = it.contents
      val bytes = result.toByteArray(Charsets.ISO_8859_1)
      val bytesHex = byteArrayToHex(bytes)
      val resHex =  "(${bytes.size}) " + bytesHex
      val resUTF = String(bytes, Charsets.UTF_8)
      tvResult.text = result
      tvHex.text = resHex
      tvAltUTF.text = resUTF
    }
  }

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge(navigationBarStyle = SystemBarStyle.light(Color.TRANSPARENT, Color.TRANSPARENT))
    setContentView(R.layout.activity_main)
    setSupportActionBar(toolbar)
    setInsetsPadding(toolbar, top=dpToPx(-8f), left=0, right=0)
    setInsetsPadding(llResult, bottom=0, left=0, right=0)
    btScanQR.setOnClickListener { startQRCodeScanner(true) }
    btScanBar.setOnClickListener { startQRCodeScanner(false) }
  }

  private fun startQRCodeScanner(qr: Boolean = true) {
    val options = ScanOptions().apply {
      if (qr)
        setDesiredBarcodeFormats(ScanOptions.QR_CODE)
      else
        setDesiredBarcodeFormats(ScanOptions.ONE_D_CODE_TYPES)
      setBeepEnabled(false)
      setOrientationLocked(true)
    }
    scanCodeLauncher.launch(options)
  }
}
