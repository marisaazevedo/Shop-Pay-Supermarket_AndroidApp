package org.feup.apm.codegen

import android.content.Intent
import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import androidx.activity.SystemBarStyle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.widget.Toolbar

fun byteArrayToHex(ba: ByteArray): String {
  val sb = StringBuilder(ba.size * 2)
  for (b in ba) sb.append(String.format("%02x", b))
  return sb.toString()
}

class MainActivity : AppCompatActivity() {
  private val toolbar by lazy { findViewById<Toolbar>(R.id.toolbar) }
  private val interior by lazy { findViewById<LinearLayout>(R.id.ll_interior) }
  private val edNumber by lazy { findViewById<EditText>(R.id.ed_number) }
  private val edMsg by lazy { findViewById<EditText>(R.id.ed_msg) }
  private val btBar by lazy { findViewById<Button>(R.id.bt_bar) }
  private val btQR by lazy { findViewById<Button>(R.id.bt_qr) }

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge(navigationBarStyle = SystemBarStyle.light(Color.TRANSPARENT, Color.TRANSPARENT))
    setContentView(R.layout.activity_main)
    setSupportActionBar(toolbar)
    setInsetsPadding(toolbar, top=dpToPx(-8f), left=0, right=0)
    setInsetsPadding(interior, left=0, right=0)
    btBar.setOnClickListener { onButtonClick(it) }
    btQR.setOnClickListener { onButtonClick(it) }
  }

  private fun onButtonClick(vw: View) {
    val intent = Intent(this, ShowCodeActivity::class.java)
    when (vw.id) {
      R.id.bt_bar -> {
        val nr = if (edNumber.text.isEmpty())
          "00000000001"
        else
          edNumber.text.toString()
        intent
          .putExtra("type", 0)
          .putExtra("value", nr)
      }
      R.id.bt_qr -> {
        val msg = if (edMsg.text.isEmpty())
          "Just a simple text message"
        else
          edMsg.text.toString()
        intent
          .putExtra("type", 1)
          .putExtra("value", msg)
      }
    }
    startActivity(intent)
  }
}