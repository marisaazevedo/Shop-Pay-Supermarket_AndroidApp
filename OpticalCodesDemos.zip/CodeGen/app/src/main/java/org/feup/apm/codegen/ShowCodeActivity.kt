package org.feup.apm.codegen

import android.graphics.Bitmap
import android.graphics.Color
import android.os.Bundle
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.SystemBarStyle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import com.google.zxing.BarcodeFormat
import com.google.zxing.EncodeHintType
import com.google.zxing.MultiFormatWriter
import com.google.zxing.common.BitMatrix
import java.util.*
import kotlin.concurrent.thread

private const val SIZE = 600

class ShowCodeActivity : AppCompatActivity() {
  private val screen by lazy { findViewById<LinearLayout>(R.id.ll_screen) }
  private val tvTitle by lazy { findViewById<TextView>(R.id.tv_title) }
  private val tvValue by lazy { findViewById<TextView>(R.id.tv_content) }
  private val tvHex by lazy { findViewById<TextView>(R.id.tv_hex) }
  private val ivCode by lazy { findViewById<ImageView>(R.id.img_code) }
  private lateinit var content: String

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge(navigationBarStyle = SystemBarStyle.light(Color.TRANSPARENT, Color.TRANSPARENT))
    setContentView(R.layout.activity_show_code)
    setInsetsPadding(screen, top=0, bottom=0, left=0, right=0)

    val type = intent.getIntExtra("type", 0)
    val value = intent.getStringExtra("value") ?: ""

    content = "Value: $value"
    tvTitle.text = if (type == 0) "Bar Code" else "QR Code"
    tvValue.text = content
    val hexValue = byteArrayToHex(value.toByteArray(Charsets.UTF_8))
    val hex = "(${hexValue.length/2}) " + hexValue
    tvHex.text = hex

    thread {
      encodeAsBitmap(type, String(value.toByteArray(Charsets.UTF_8), Charsets.ISO_8859_1)).also {
        runOnUiThread { ivCode.setImageBitmap(it) }
      }
    }
  }

  private fun encodeAsBitmap(type: Int, str: String): Bitmap? {
    val result: BitMatrix
    val hints = Hashtable<EncodeHintType, String>().apply {
      put(EncodeHintType.CHARACTER_SET, "ISO-8859-1")
    }
    var width = SIZE
    val format = if (type == 0) {
      width *= 2
      BarcodeFormat.UPC_A
    }
    else
      BarcodeFormat.QR_CODE

    try {
      result = MultiFormatWriter().encode(str, format, width, SIZE, hints)
    }
    catch (e: Exception) {
      content += "\n${e.message}"
      runOnUiThread { tvValue.text = content }
      return null
    }
    val w = result.width
    val h = result.height
    val colorDark = resources.getColor(R.color.black, null)
    val colorLight = resources.getColor(R.color.white, null)
    val pixels = IntArray(w * h)
    for (line in 0 until h) {
      val offset = line * w
      for (col in 0 until w)
        pixels[offset + col] = if (result.get(col, line)) colorDark else colorLight
    }
    return Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888).apply { setPixels(pixels, 0, w, 0, 0, w, h) }
  }
}