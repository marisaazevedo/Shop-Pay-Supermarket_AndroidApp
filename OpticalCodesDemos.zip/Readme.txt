Demos using the Google Zxing (Zebra Crossing) library with apps to read and generate optical codes.
There are two Android applications:

Code Scanner
============
Scans and shows the messages read from QRcodes and barcodes.
It uses a scanning activity embedded on an external library, called com.journeyapps:zxing-android-embedded
That Activity is called implicitly with startActivityForResult(), using a new API envolving that Activity
Launcher, obtained when registering a callback, replacing OnActivityResult(). That callback is registered
(creating the Launcher) with registerForActivityResult().

Code Gen
========
Generates a QR code (or a bar code) to represent a String message, transforms it into
a Bitmap, and displays it.
The QR code (or bar code) is generated as an array of bytes that is transformed into
the 2D bitmap code.
Experiment with different message sizes (for the QR code), from a few tens of
characters through near 1000 characters. Observe that the QR code shape changes with the
message size.
QR codes contain some redundancy, allowing some error correction if optical
acquisition errors occur, but if the QR code is complex it could be difficult
to read and decode it (depends on the screen resolution where it is displayed,
and on the camera resolution for its acquisition).